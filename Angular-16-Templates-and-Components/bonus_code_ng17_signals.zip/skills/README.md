# Skills

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 17.2.2.
Run npm install against the unzipped folder

## Axle's Note
As mentioned during the bootcamp, this code was done quickly just to show some of the 
new and latest features of Angular as it pertains to the content of this particular bootcamp

The code is raw and unpolished. Since there are no "best practices" yet, use the code to your
discretion. The programming itself may change in the future.

Thank you for your support :)

