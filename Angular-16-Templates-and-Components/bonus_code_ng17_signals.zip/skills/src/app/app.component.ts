import { Component, effect, viewChild } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FirstChildComponent } from "./first-child/first-child.component";
//
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, FirstChildComponent],
  templateUrl: './app.component.html',
})
export class AppComponent {
  firstChild = viewChild(FirstChildComponent);
  //@ViewChild('child') firstChild!:FirstChildComponent;
  title = 'skills';
  parentfName = "";
  constructor(){
    effect(()=>{
      console.log(this.firstChild()?.fName);
    });
  };
  ngAfterViewInit(){
    //console.log(this.firstChild()?.fName);
  }
}
