import { Component, OnInit, model } from '@angular/core';

@Component({
  selector: 'app-first-child',
  standalone: true,
  imports: [],
  templateUrl: './first-child.component.html',
  styles: ``
})
export class FirstChildComponent implements OnInit{
  fName = model<string>('');
  ngOnInit(): void {
    //console.log('First Child Component:' + this.fName);
  };
  updatefName(event: Event){
    let updatedName = (<HTMLInputElement>event.target).value;
    this.fName.update(currValue => updatedName);
  };

};
