import { Component, OnInit } from '@angular/core';
import * as employeeData from "./../db.json";
import { ActivatedRoute, Router } from "@angular/router";
//
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
//
export class LoginComponent implements OnInit {
  empID : string = "";
  name : string = "";
  pageEdit : number = 0;
  empData : any = (employeeData as any);
  //
  constructor(private route:ActivatedRoute, private router:Router ) { }
  //
  ngOnInit(): void {
    this.route.queryParams.subscribe(p => {
      this.empID = p['id'] || 0;
      this.pageEdit = +p['edit'] || 0;
      console.log(this.empID + "-" + this.pageEdit);      
    })
  }
  //
}
