import { Component, OnInit } from '@angular/core';
import * as employeeData from "./../db.json";
import { ActivatedRoute, Router } from "@angular/router";
//
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
//
export class LoginComponent implements OnInit {
  empID : string = "";
  name : string = "";
  empData : any = (employeeData as any);
  //
  constructor(private route:ActivatedRoute, private router:Router ) { }
  //
  ngOnInit(): void {
    this.route.params.subscribe(p => {
      //console.log(p["id"]);   
      //console.log(this.empData.employees[p["id"]]);
      this.name = this.empData.employees[p["id"]];  
      console.log(this.name); 
    })
  }
  //
}
