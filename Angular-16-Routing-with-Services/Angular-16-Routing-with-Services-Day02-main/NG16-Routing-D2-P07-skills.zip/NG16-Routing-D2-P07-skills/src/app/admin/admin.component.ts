import { Component } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
//
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  allAdmins : any = [];
  //message! : {};
  //
  constructor(private activatedRoute : ActivatedRoute) { 
    //this.message = this.activatedRoute.snapshot.data;
    //console.log(this.message);
    this.allAdmins = this.activatedRoute.snapshot.data["isAdminResolved"];
  }
//
}
