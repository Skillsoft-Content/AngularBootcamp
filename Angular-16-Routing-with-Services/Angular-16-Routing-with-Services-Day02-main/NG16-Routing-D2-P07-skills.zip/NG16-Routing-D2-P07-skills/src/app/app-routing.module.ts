import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from "./home/home.component";
import { RegisterComponent } from "./register/register.component";
import { LoginComponent } from "./login/login.component";
import { NotFoundComponent } from './not-found.component';
//import { AdminComponent } from "./admin/admin.component";
import { restrictedGuard } from './restricted.guard';
import { administratorsResolver } from './administrators.resolver';
//
const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path:'home', component:HomeComponent},
  { path:'register', component:RegisterComponent},
  { path:'login', component:LoginComponent, children:[
    { path:':id', loadChildren:() => import('./admin/admin.module')
      .then(m => m.AdminModule), 
      data : { message:"Remember to log out!" },
      resolve : { isAdminResolved : administratorsResolver}
    },    
  ]},  
  { path:'**', component:NotFoundComponent}
];
//
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
//
export class AppRoutingModule { }
