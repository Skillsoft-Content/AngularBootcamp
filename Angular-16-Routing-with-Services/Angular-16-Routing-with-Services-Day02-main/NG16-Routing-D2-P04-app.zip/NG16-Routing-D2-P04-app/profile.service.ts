import { Injectable } from '@angular/core';
//
@Injectable({
  providedIn: 'root'
})
//
export class ProfileService {
  loginStatus : Boolean = false;
  constructor() { }
  //
  login(){
    this.loginStatus = true;
    return this.loginStatus;
  }
  logout(){
    this.loginStatus = false;
    return this.loginStatus;
  }
  status(){
    return this.loginStatus;
  }
//
}
