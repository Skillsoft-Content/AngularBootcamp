import { CanActivateFn } from '@angular/router';
//
export const restrictedGuard: CanActivateFn = (route, state) => {
  return false;
};
