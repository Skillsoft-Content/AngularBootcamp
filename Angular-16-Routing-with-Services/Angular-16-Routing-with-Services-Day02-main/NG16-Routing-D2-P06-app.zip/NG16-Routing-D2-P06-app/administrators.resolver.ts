import { ResolveFn } from '@angular/router';

export const administratorsResolver: ResolveFn<boolean> = (route, state) => {
  return true;
};
