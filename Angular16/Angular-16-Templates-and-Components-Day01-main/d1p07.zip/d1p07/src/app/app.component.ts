import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'skills2';
  divColor = "Black";
  approved = false;
  userInput = "Hello Skillsoft";
  messages : string[] = ["Hello", "from", "Skillsoft"];
  getTitle(){
    return this.title;
  }
  makeBlue(){
    this.divColor = "Blue";
    this.approved = !this.approved;
  }
  handleInput(event : Event){
    //console.log("Event handled!" + event)
    this.userInput = (<HTMLInputElement>event.target).value ;
  }
  displayUserInput(){
    return this.userInput;
  }
}
