import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title : string = 'skills';
  divColor : string = "Black";
  approved : boolean = false;
  userInput : string = "Hello Skillsoft";
  messages : string[] = ["Hello", "from", "Skillsoft"];
  //messageToChildren : string = "Hello from parent.";
  //
  getTitle(){
    return this.title;
  }
  //
  makeBlue(){
    this.divColor = "Blue";
    this.approved = !this.approved;
  }
  //
  handleInput(event : Event){
    //console.log("Event handled!");
    this.userInput = (<HTMLInputElement>event.target).value ;
  }
  //
  displayUserInput(){
    return this.userInput;
  }
  //
  messageToChildren(){
    return "Hello from a method in the parent app!"
  }
  //
  messageFromChildren(msg: string) {
    console.log(msg);
  }

}
