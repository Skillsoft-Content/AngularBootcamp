import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-first-child',
  templateUrl: './first-child.component.html',
  styleUrls: ['./first-child.component.css']
})
export class FirstChildComponent implements OnInit {
  @Input() messageFromParent : string = "";
  @Output() eventEmitter = new EventEmitter<string>();
  messageFromFirstChild : string = "Message from first-child";
  selectedRBValue : string = "Female";
  constructor() { }

  ngOnInit(): void {
    this.eventEmitter.emit(this.selectedRBValue);
  }
  //
  generateChildMessage() {
    this.eventEmitter.emit(this.messageFromFirstChild);
  }
  //
  generateGenderMessage(event : Event) {
    this.selectedRBValue = (<HTMLInputElement>event.target).value;
    this.eventEmitter.emit(this.selectedRBValue);
  }

}
