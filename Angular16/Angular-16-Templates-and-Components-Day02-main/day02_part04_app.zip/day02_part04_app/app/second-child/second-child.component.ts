import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-second-child',
  templateUrl: './second-child.component.html',
  styleUrls: ['./second-child.component.css']
})
export class SecondChildComponent implements OnInit {
  approved : boolean = false;
  @ViewChild('fName') fName! : ElementRef;
  constructor() { }

  ngOnInit(): void {
  }

  getApproval(cb : HTMLInputElement){
    console.log(this.fName.nativeElement.value);
  }
  calledFromParent(){
    console.log("Called from Parent");
  }
}
