import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title : string = 'skills2';
  compStatus : string = "App Component - Top Component";
  //messageToChildren : string = "Hello from app component";
  //
  messageToChildren(){
    return "Hello from a method in the parent app!"
  }
  messageFromChildren(msg: string) {
    console.log(msg);
  }
}
