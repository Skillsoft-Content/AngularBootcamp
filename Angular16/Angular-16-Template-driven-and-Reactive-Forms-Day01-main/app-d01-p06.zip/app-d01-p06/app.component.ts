import { Component } from '@angular/core';
import { NgForm } from "@angular/forms";
import { User } from "./user";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent {
  title = 'skills';
  user : User = {};
  departments : string[] = ["Sales", "Accounting", "CustomerSupport", "ContentCreation"];
  prizes : string[] = ["Cash", "Voucher", "Lunch"];
  selectedPrize : string = "";
  //
  constructor() {
    this.user = new User();
    this.selectedPrize = this.prizes[0];
  };
  //
  onSubmit(userDetails : NgForm){
    console.log(userDetails);
  }

}
