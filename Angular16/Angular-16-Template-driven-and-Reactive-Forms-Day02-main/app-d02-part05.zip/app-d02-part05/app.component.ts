import { Component, OnInit} from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent implements OnInit{
  userDetails! : FormGroup;
  constructor(){}
  //
  ngOnInit(): void {
    this.userDetails = new FormGroup({
      fgFullName : new FormGroup({
        firstName : new FormControl(
          null, 
          [Validators.required, Validators.minLength(3), this.alphaCheck]
        ),
        lastName : new FormControl(null, Validators.required),  
      }),
      email : new FormControl(),
      department : new FormControl(),
      prizes : new FormArray([
        new FormControl(null),
        new FormControl(null),
        new FormControl(null),
      ])
    });
  }
  //
  onSubmit(){
    console.log(this.userDetails);
  }
  //
  alphaCheck(control: AbstractControl): { [key: string]: boolean } | null  {
    const regExp : RegExp = /^[A-Za-z]+$/;
    const cValue = control.value;
    if (!regExp.test(cValue)) {
      return { alphaCheck: true };
    }
    return null;
  }
  //
  get firstName() { return this.userDetails.get('fgFullName').get('firstName')!; };
  get lastName() { return this.userDetails.get('fgFullName').get('lastName')!; };
  get email() { return this.userDetails.get('email')!; };
  get department() { return this.userDetails.get('department')!; };
  get allPrizes(){
    return this.userDetails.get('prizes') as FormArray;
  };

}

