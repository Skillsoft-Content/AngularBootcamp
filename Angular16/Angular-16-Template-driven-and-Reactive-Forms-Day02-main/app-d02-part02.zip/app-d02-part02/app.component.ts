import { Component, OnInit} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent implements OnInit{
  userDetails! : FormGroup;
  constructor(){}
  //
  ngOnInit(): void {
    this.userDetails = new FormGroup({
      firstName : new FormControl(
        null, 
        [Validators.required, Validators.minLength(3), Validators.maxLength(36)]
      ),
      lastName : new FormControl(null, Validators.required)  
    });
  }
  //
  onSubmit(){
    console.log(this.userDetails);
  }
  //
  get firstName() { return this.userDetails.get('firstName')!; }
}

