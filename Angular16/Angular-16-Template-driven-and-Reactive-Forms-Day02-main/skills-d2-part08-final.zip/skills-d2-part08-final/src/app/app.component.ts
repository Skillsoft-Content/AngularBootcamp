import { Component } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Observable } from "rxjs";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent{
  //
  userDetails = this.fb.group({
    fullName : this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required], 
    }),
    email: ['', Validators.required, this.restrictEmail],
    department:['', Validators.required]
  });
  //
  constructor(private fb: FormBuilder){}
  //
  onSubmit(userDetails : FormGroup){
    console.log(this.userDetails.value);
  }
  //
  restrictEmail(control : AbstractControl) : Promise<any> | Observable<any>{
    return new Promise((resolve, reject) => {
      setTimeout(()=>{      
        if(control.value === "axle@skillsoft.com")
          resolve({restrictEmail:false});
        else
          resolve(null);
      }, 3000);
		});
  };
  //
}
//
