import { Component, OnInit} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent implements OnInit{
  userDetails! : FormGroup;
  constructor(){}
  //
  ngOnInit(): void {
    this.userDetails = new FormGroup({
      firstName : new FormControl(),
      lastName : new FormControl()  
    });
  }
  //
  onSubmit(){
    console.log(this.userDetails.value);
  }
}

