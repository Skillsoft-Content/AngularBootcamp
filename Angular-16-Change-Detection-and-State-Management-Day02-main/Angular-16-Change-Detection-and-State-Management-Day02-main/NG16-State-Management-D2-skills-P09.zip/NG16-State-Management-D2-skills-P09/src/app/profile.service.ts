import { Injectable, signal } from '@angular/core';
import { Observable, of } from "rxjs";
//
@Injectable({
  providedIn: 'root'
})
//
export class ProfileService {
  private userStatus$ = new Observable<boolean>( );
  isLoggedIn = signal(this.userStatus$); 
  //
  login(){
    //this.isLoggedIn.next(true);
    this.isLoggedIn.set( of ( true ) );
  }
  logout(){
    this.isLoggedIn.set( of ( false ) );
  }
}
