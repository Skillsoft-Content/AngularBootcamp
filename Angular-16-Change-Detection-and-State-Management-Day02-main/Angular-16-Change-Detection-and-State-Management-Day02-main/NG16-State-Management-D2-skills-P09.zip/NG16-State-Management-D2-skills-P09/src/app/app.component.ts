import { Component, inject } from '@angular/core';
import { ProfileService } from "./profile.service";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent {
  title = 'profile';
  pService = inject(ProfileService);
  status : boolean = false;
  userLoggedIn = inject(ProfileService);
  constructor(){
    this.pService.logout();
  }
  //
  logout(){
    console.log("in logout");
    this.pService.logout();
  }
}
