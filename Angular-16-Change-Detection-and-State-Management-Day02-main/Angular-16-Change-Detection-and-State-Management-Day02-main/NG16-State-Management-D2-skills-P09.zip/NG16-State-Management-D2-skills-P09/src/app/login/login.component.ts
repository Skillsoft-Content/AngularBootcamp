import { Component, inject } from '@angular/core';
import { ProfileService } from "./../profile.service";
//
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
//
export class LoginComponent {
  pService = inject(ProfileService);
  loginUser(): void {  
    this.pService.login();
    this.pService.isLoggedIn().subscribe(x => console.log(x));
  }
}
