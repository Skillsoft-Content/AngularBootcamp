import { Injectable } from '@angular/core';
//import { BehaviorSubject } from "rxjs";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
//
@Injectable({
  providedIn: 'root'
})
//
export class ProfileService {
  //isLoggedIn = new BehaviorSubject<boolean>(false);
  constructor(private store : Store<{loginUser : {loginStatus : boolean}}>) { }
  // login(){
  //   this.isLoggedIn.next(true);
  // }
  // logout(){
  //   this.isLoggedIn.next(false);
  // }
  loginStatus(){
    return this.store.select('loginUser') as Observable<{loginStatus : boolean}>;
  }
}
