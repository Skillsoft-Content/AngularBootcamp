export class Employee {
  id?: string;
  empname?: string;
  emppass?: string;
  dept?: string;
  bd?: Date;
  token?: string;
  grade?: number;
}