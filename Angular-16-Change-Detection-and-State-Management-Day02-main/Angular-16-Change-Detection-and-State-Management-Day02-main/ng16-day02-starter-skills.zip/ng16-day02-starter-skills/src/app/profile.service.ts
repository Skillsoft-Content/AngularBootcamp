import { Injectable } from '@angular/core';
import { Subject } from "rxjs";
//
@Injectable({
  providedIn: 'root'
})
//
export class ProfileService {
  isLoggedIn = new Subject<boolean>();
  constructor() { }
  login(){
    this.isLoggedIn.next(true);
  }
  logout(){
    this.isLoggedIn.next(false);
  }
  loginStatus(){
    return this.isLoggedIn.asObservable();
  }
}
