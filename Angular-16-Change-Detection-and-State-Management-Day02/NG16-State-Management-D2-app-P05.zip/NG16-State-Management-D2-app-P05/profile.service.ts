import { Injectable } from '@angular/core';
//import { BehaviorSubject } from "rxjs";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { LoginUser } from "./profile.actions";
//
@Injectable({
  providedIn: 'root'
})
//
export class ProfileService {
  //isLoggedIn = new BehaviorSubject<boolean>(false);
  constructor(private store : Store<{loginUser : {loginStatus : boolean}}>) { }
  login(){
    this.store.dispatch(new LoginUser(true));
  }
  // logout(){
  //   this.isLoggedIn.next(false);
  // }
  loginStatus(){
    return this.store.select('loginUser') as Observable<{loginStatus : boolean}>;
  }
}
