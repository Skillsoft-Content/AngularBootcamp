import { Action } from "@ngrx/store";
import { LOGIN_USER } from "./profile.actions";
//
const initialState = {
  loginStatus : false
};
//
export function profileReducer( state = initialState, action:Action ){  
  if(action.type == LOGIN_USER){
    return {
      loginStatus : true
    }
  } else {
    return { loginStatus : false }
  }
}
