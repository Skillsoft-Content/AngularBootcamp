import { Component, OnInit } from '@angular/core';
import { ProfileService } from "./profile.service";
import { Subscription } from "rxjs";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent implements OnInit{
  title = 'profile';
  userLoggedIn! : { loginStatus : boolean };
  //private loginSubscription = new Subscription();
  //
  constructor(public pService : ProfileService){
  }
  ngOnInit(): void {
    //this.pService.logout();
    this.pService.loginStatus()
    .subscribe(status => {
       this.userLoggedIn = status;
     });
   //console.log(this.userLoggedIn);  
  }
  logout(){
    this.pService.logout();
    this.pService.loginStatus()
    .subscribe(status => {
       this.userLoggedIn = status;
     });
    //console.log(this.userLoggedIn);  
   } 
}
