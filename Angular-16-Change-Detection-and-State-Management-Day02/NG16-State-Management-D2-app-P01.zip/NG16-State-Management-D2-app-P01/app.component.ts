import { Component, OnInit } from '@angular/core';
import { ProfileService } from "./profile.service";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent implements OnInit{
  title = 'profile';
  userLoggedIn : boolean = false;
  //
  constructor(public pService : ProfileService){
  }
  ngOnInit(): void {
    //this.pService.logout();
    this.pService.isLoggedIn.subscribe(status => {
       this.userLoggedIn = status;
     });
   console.log(this.userLoggedIn);  
  }
}
