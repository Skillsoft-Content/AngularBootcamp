import { Action } from "@ngrx/store";
import { LOGIN_USER, LOGOUT_USER } from "./profile.actions";
//
const initialState = {
  loginStatus : false
};
//
export function profileReducer( state = initialState, action:Action ){  
  switch ( action.type ) {
    case LOGIN_USER:
      return {
        loginStatus : true
      };
      break;
    case LOGOUT_USER:
      return {
        loginStatus : false
      };
      break; 
    default: 
    return { loginStatus : false };
      break;    
  }
}
