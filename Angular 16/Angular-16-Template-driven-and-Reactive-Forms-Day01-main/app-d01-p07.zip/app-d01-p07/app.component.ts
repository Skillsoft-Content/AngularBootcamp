import { Component, ViewChild } from '@angular/core';
import { NgForm } from "@angular/forms";
import { User } from "./user";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent {
  @ViewChild('userDetails') userDetailsForm!: NgForm
  title = 'skills';
  user : User = {};
  departments : string[] = ["Sales", "Accounting", "CustomerSupport", "ContentCreation"];
  prizes : string[] = ["Cash", "Voucher", "Lunch"];
  selectedPrize : string = "";
  //
  constructor() {
    this.user = new User();
    this.selectedPrize = this.prizes[0];
  };
  //
  onSubmit(){
    console.log(this.userDetailsForm.value);
  }
  //
  suggestEmail(event: any){
    this.userDetailsForm.form.patchValue(
      {userMail : this.user.firstName + "." + this.user.lastName + "@skillsoft.com"}
    );
  }

}
