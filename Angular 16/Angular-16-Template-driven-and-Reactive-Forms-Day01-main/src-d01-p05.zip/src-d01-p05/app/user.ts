export class User {
    public firstName?: string;
    public lastName?: string;
    public email?: string;
  }
  