import { Component } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent{
  //
  userDetails = this.fb.group({
    fullName : this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required], 
    }),
    email: ['', Validators.required],
    department:['', Validators.required]
  });
  //
  constructor(private fb: FormBuilder){}
  //
  onSubmit(userDetails : FormGroup){
    console.log(this.userDetails.value);
  }
//
}
//
