import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-child-child',
  templateUrl: './first-child-child.component.html',
  styleUrls: ['./first-child-child.component.css']
})
export class FirstChildChildComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  ngDoCheck(){
    console.log("grand child change detected");
  }
}
