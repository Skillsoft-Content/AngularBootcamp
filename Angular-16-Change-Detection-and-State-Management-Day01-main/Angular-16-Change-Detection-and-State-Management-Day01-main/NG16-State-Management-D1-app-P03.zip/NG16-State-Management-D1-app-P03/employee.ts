export class Employee {
  id?: number;
  empname?: string;
  emppass?: string;
}