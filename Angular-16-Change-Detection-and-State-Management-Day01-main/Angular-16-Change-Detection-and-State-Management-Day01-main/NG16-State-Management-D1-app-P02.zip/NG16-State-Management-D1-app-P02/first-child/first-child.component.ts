import { Component, OnInit, Input } from '@angular/core';
import { Employee } from "./../employee";
//
@Component({
  selector: 'app-first-child',
  templateUrl: './first-child.component.html',
  styleUrls: ['./first-child.component.css'],
})
//
export class FirstChildComponent implements OnInit {
  //@Input() messageFromParent : string = "";
  @Input() employee! : Employee;
  //
  constructor() { }
  ngOnInit(): void { }
  ngDoCheck(){
    console.log("first-child change detected");
  }
}
