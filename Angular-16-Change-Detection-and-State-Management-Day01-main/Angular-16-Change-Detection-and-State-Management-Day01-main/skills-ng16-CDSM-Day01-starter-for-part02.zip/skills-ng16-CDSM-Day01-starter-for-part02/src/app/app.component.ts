import { Component } from '@angular/core';
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
//
export class AppComponent {
  title : string = 'skills';
  messageToChildren : string = "Hello from app";
  //
  changeMessage(){
    this.messageToChildren  = "Hello from App component";
  }
}
