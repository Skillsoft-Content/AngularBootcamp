export class Employee {
  id?: string;
  empname?: string;
  emppass?: string;
}