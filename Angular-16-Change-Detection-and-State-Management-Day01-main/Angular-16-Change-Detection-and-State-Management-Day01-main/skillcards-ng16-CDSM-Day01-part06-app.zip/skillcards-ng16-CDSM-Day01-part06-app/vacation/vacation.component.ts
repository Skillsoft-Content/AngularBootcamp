import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, Output } from '@angular/core';
import { Employee } from "./../employee";
//
@Component({
  selector: 'app-vacation',
  templateUrl: './vacation.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
//
export class VacationComponent {
  @Input() employee!:Employee;
  @Output() toggleEmployee = new EventEmitter();
  //
  constructor(private cd: ChangeDetectorRef) { }
  rendered(){
    console.log("Rendered");  
    
    //this.cd.markForCheck();  
  }
  ngOnChanges() {
    this.cd.markForCheck;
  }
  changeName(){
    this.toggleEmployee.emit();
  }
}
