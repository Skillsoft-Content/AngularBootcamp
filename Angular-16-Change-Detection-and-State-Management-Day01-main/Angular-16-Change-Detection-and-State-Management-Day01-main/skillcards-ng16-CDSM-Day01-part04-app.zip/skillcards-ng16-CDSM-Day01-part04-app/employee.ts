export class Employee {
  id!         : number;
  username!   : string;
  password!   : string;
  onvacation! : boolean;
}
