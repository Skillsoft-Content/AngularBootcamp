import { Component, Input } from '@angular/core';
import { Employee } from "./../employee";
//
@Component({
  selector: 'app-vacation',
  templateUrl: './vacation.component.html',
  styles: [
  ]
})
//
export class VacationComponent {
  @Input() employee!:Employee;
  //
  rendered(){
    console.log("Rendered");    
  }

}
