import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
//
@Component({
  selector: 'app-second-child',
  templateUrl: './second-child.component.html',
  styleUrls: ['./second-child.component.css']
})
//
export class SecondChildComponent implements OnInit {

  constructor( private http : HttpClient ) { };

  ngOnInit(): void {
  };
  ngDoCheck(){
    console.log("second-child change detected");
  };

  getData(){
    this.http.get<any>('https://jsonplaceholder.typicode.com/posts/1')
    .subscribe({
      next: x => {
        console.log(x);            
      },
      error: error => { console.log(error); }
    })
  };


};
