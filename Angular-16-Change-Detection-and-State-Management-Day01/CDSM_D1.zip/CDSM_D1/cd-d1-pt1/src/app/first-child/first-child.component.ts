import { Component, OnInit, Input } from '@angular/core';
//
@Component({
  selector: 'app-first-child',
  templateUrl: './first-child.component.html',
  styleUrls: ['./first-child.component.css'],
})
//
export class FirstChildComponent implements OnInit {
  @Input() messageFromParent : string = "";
  //
  constructor() { };

  ngOnInit(): void {    
    // setTimeout ( ( )  =>  {
    //   console.log("This is printed after 2 seconds");      
    // }, 4000 );
  };
  
  ngDoCheck(){
    console.log("first-chilld change   detected");
  };
  
};
