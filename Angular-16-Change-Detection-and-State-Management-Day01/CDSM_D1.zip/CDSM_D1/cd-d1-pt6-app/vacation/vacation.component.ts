import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, Output } from '@angular/core';
import { Employee } from './../employee';

@Component({
  selector: 'app-vacation',
  templateUrl: './vacation.component.html',
  styles: [],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VacationComponent {
  @Input() employee!:Employee;
  @Output() toggleEmployee = new EventEmitter();
  //
  constructor ( private cd: ChangeDetectorRef ) { };
  rendered(){
    //this.cd.markForCheck();  
    console.log("Rendered");    
  };
  ngOnChanges() {
    this.cd.markForCheck;
  };
  changeName(){
    this.toggleEmployee.emit();
  };

};
