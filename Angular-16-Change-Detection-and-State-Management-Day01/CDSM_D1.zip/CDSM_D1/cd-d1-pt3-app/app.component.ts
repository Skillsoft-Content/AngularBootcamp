import { Component } from '@angular/core';
import { Employee } from "./employee";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
//
export class AppComponent {
  title : string = 'skills';
  employee : Employee = new Employee();
  messageToChildren : string = "Hello from app";
  //
  constructor() {
    this.employee.empname = 'Axle';
  };

  changeMessage(){
    //this.messageToChildren  = "Hello from App component";
    this.employee.empname = 'Axle Barr';
    // this.employee = {
    //   id : "1",
    //   empname : "Axle Barr",
    //   emppass : "Axle"
    // };
  };
};
