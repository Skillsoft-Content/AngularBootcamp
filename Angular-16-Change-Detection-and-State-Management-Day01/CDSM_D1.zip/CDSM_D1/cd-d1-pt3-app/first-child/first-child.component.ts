import { Component, OnInit, Input, ChangeDetectionStrategy, ChangeDetectorRef  } from '@angular/core';
import { Employee } from "./../employee";
//
@Component({
  selector: 'app-first-child',
  templateUrl: './first-child.component.html',
  styleUrls: ['./first-child.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
//
export class FirstChildComponent implements OnInit {
  //@Input() messageFromParent : string = "";
  @Input() employee! : Employee;
  //
  constructor(private cd : ChangeDetectorRef) { };
  ngOnInit(): void { };
  ngDoCheck(){
    this.cd.detectChanges();
    console.log("first-chilld change detected");
  };
};
