import { Component, OnInit } from '@angular/core';
import { Employee } from "./employee";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
//
export class AppComponent implements OnInit{
  title = 'skillcards';
  employees! : Employee[];
  //
  editEmployees(): void {
    this.employees[1].username="Janice";
    //this.employees[1] = {...this.employees[1], username:"Janice"};
  }

  ngOnInit(): void {
    this.employees = [
      {
        "id":1,
        "username":"Axle",
        "password":"1234",
        "onvacation":false
      },
      {
        "id":2,
        "username":"Jane",
        "password":"1234",
        "onvacation":false
      },
      {
        "id":3,
        "username":"Mary",
        "password":"1234",
        "onvacation":false
      }
    ]
  }
}
