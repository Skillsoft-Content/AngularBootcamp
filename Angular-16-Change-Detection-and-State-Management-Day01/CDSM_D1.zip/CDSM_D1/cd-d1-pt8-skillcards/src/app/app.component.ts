import { Component, OnInit, NgZone, ChangeDetectorRef } from '@angular/core';
import { Employee } from "./employee";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
//
export class AppComponent implements OnInit{
  title = 'skillcards';
  employees! : Employee[];
  counter : number = 0;
  displayDiv : number = 0;
  interval : any;
  //
  constructor(private ngZone : NgZone, private cdr : ChangeDetectorRef){};
  editEmployees(): void {
    this.employees[1].username="Janice";
    //this.employees[1] = {...this.employees[1], username:"Janice"};
  };
  countDaysInZone(){
    this.ngZone.run(() => {this.startCount()});
  };
  countDaysOutZone(){
    this.displayDiv = 1;
    this.ngZone.runOutsideAngular(() => {this.startCount()});
  }

  startCount(){
    this.counter = 0;
    let intervalFn = () => {this.updateCount()};
    this.interval = setInterval(intervalFn, 500);
  };

  updateCount(){
    this.counter++;
    if ( this.counter >= 10 ) {
      clearInterval(this.interval);
      this.displayDiv = 2;
      this.cdr.detectChanges();
      //this.ngZone.run(()=>{this.counter});
    };
  };

  ngOnInit(): void {
    this.employees = [
      {
        "id":1,
        "username":"Axle",
        "password":"1234",
        "onvacation":false
      },
      {
        "id":2,
        "username":"Jane",
        "password":"1234",
        "onvacation":false
      },
      {
        "id":3,
        "username":"Mary",
        "password":"1234",
        "onvacation":false
      }
    ]
  };
};
